#' HCM Freeway Function
#'
#' This function takes link-level attributes
#' and default values to calculate hourly flow rates
#' for freeway segments.
#' @inheritParams hcm_calculate
#' @export
#' 
#' @import dplyr
#' 
#' @details This section documents some of the assumptions used
#' by the function.
#' Factors determined by the \code{at}.
#' \itemize{
#'  \item{Lane width:\cr}{Urban: 12'; Suburban: 12'; Rural: 11'}
#'  \item{Right-side lateral clearance:\cr}{Urban: 4'; Suburban: 5'; Rural: 6'}
#'  \item{Ramp density (ramps per mile):\cr}{Urban: 0.5; Suburban: 0.5; Rural: 0.25}
#'  \item{Proportion of Heavy Vehicles:\cr}{Urban: 0.14; Suburban: 0.17; Rural: 0.20}
#' }
#' 
#' Factors determined by the \code{terrain}.
#' \itemize{
#'  \item{Passenger-Car Equivalent of Heavy Vehicles:\cr}{level: 1.5; rolling: 2.5; mountain: 4.5}
#'  \item{Passenger-Car Equivalent of Recreational Vehicles:\cr}{level: 1.2; rolling: 2.0; mountain: 4.0}
#' }
#' 
#' @examples
#' \dontrun{
#' hcm_freeway(LOS = "E")
#' }
#' 
#' @source HCM Chapter 11
hcm_freeway <- function(speed = FALSE,
                        LOS = "E",
                        at=2,
                        lanes = 2,
                        terrain = "rolling"){
  
  # ---- Argument Checking ----
  if (lanes < 2){
    warning("Freeway lanes must be >=2. Setting to 2.")
    lanes <- 2
  }
  # ---- End Checking ----
  
  # Lane width
  lw <- ifelse(at == 3,12,
               ifelse(at == 2,12,11))
  # Adjustment for lane width (Exhibit 11-8)
  flw <- ifelse(lw >= 12,0,
               ifelse(lw >= 11,1.9,6.6))
  # Right-side lateral clearance
  rlc <- ifelse(at == 3,6,
                ifelse(at == 2,5,4))
  # Adjustment for right-side lateral clearance (Exhibit 11-9)
  flc <- freewayLC %>%
    filter(RightLateralClearance == min(rlc,6),
           DirectionalLanes == min(lanes,5)) %>%
    select(flc) %>%
    as.numeric()
  # Ramp density (NCLOS defaults)
  trd <- ifelse(at == 3,.25,.5)
  # Free flow speed (Equation 11-1)
  FFS <- 75.4 - flw - flc - 3.22 * trd^.84
  if (speed){
    return(FFS)
  }
  # If calculating capacity, pick the nearest
  # FFS curve (increments of 5 mph)
  # Round FFS to the nearest 5 (max 75 min 55)
  FFS <- min(max(round(FFS / 5) * 5,55),75)

  
  # Maximum Service Flow Rate (Exhibit 11-17)
  MSF <- freewayMSF[match(FFS,freewayMSF$FFS),paste0("LOS",LOS)]
  
  # Heavy Vehicles
  # Proportion heavy vehicles (NCLOS defaults)
  # (NCLOS uses .14,.22,.20)
  Pt <- ifelse(at == 1, .14,
               ifelse(at == 2,.17,.20))
  # Passenger car equivalent (PCE) of heavy vehicles 
  # (Exhibit 11-10)
  # 1.5 if level; 2.5 if rolling; 4.5 if mountainous
  Et <- ifelse(terrain == "level",1.5,
               ifelse(terrain == "rolling",2.5,4.5))
  # Proportion RVs (NCLOS default)
  Pr <- 0
  # Passenger car equivalents (PCE) of RVs
  # (Exhibit 11-10)
  # 1.2 if level; 2.0 if rolling; 4.0 if mountainous
  Er <- ifelse(terrain == "level",1.2,
               ifelse(terrain == "rolling",2.0,4.0))
  # Adjustment for heavy vehicles (Equation 11-3)
  fhv <- 1/(1 + Pt * (Et - 1) + Pr * (Er - 1))
  
  # Driver Population
  fp <- 1 # (NCLOS)
  
  # Service Flow Rate (Equation 11-9)
  SF <- MSF * lanes * fhv * fp
  
  # Peak Hour Factor
  phf <- .95
  
  # Service Volume (hourly) (Equation 11-10)
  SV <- SF * phf
  
  SV[1,1]
}






