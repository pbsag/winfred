#' Arterial - Speed Constant Lookup
#' 
#' A lookup table that provides speed constants
#' based on posted speed limits.
#' 
#' @format A data frame with 7 observations
#' \describe{
#'  \item{SpeedLimit}{Posted speed limit on the link}
#'  \item{SpeedConstant}{Speed constant to use}
#' }
#' @source Exhibit 17-11 HCM 2010
"arterial_speedConstant"

#' Two-Lane Highway - Base Percent Time Spent Following
#' 
#' A lookup table the provides alpha and beta
#' values based on the demand flow rate.
#' 
#' @format A data frame with 8 observations
#' \describe{
#'  \item{DemandFlowRate}{Demand Flow Rate}
#'  \item{a}{alpha to use}
#'  \item{b}{beta to use}
#' }
#' @source Exhibit 15-20 HCM 2010
"bptsfCoeffTbl"

#' Freeway - Maximum Service Flow Rate
#' 
#' A lookup table that provides maximum
#' service flow rates for LOS D and E
#' based on free-flow speed.
#' 
#' @format A data frame with 5 observations
#' \describe{
#'  \item{FFS}{Free-flow Speed}
#'  \item{LOSD}{Maximum service flow rate while maintaining LOS D}
#'  \item{LOSE}{Maximum service flow rate while maintaining LOS E}
#' }
#' @source Exhibit 11-17 HCM 2010
"freewayMSF"

#' Freeway - Lateral Clearance Adjustment
#' 
#' A lookup table that provides the
#' lateral clearance adjustment to FFS
#' based on lanes and clearnace.
#' 
#' @format A data frame with 28 observations
#' \describe{
#'  \item{RightLateralClearance}{Right-side lateral clearance}
#'  \item{DirectionalLanes}{Lanes in one direction}
#'  \item{flc}{Adjustment factor}
#' }
#' @source Exhibit 11-9 HCM 2010
"freewayLC"

#' Multi-Lane Highway - Access Point Density Adjustment
#' 
#' A lookup table that provides the adjustment
#' based on access point density.
#' 
#' @format A data frame with 41 observations
#' \describe{
#'  \item{APD}{Access point density}
#'  \item{Factor}{Adjustment factor}
#' }
#' @source Exhibit 14-11 HCM 2010
"mlHighwayAPD"

#' Multi-Lane Highway - Maximum Service Flow Rate
#' 
#' A lookup table that provides maximum
#' service flow rates for LOS D and E
#' based on free-flow speed.
#' 
#' @format A data frame with 4 observations
#' \describe{
#'  \item{FFS}{Free-flow Speed}
#'  \item{LOSD}{Maximum service flow rate while maintaining LOS D}
#'  \item{LOSE}{Maximum service flow rate while maintaining LOS E}
#' }
#' @source Exhibit 14-17 HCM 2010
"mlHighwayMSF"

#' Two-Lane Highway - Grade adjustment (PTSF)
#' 
#' A lookup table that provides the adjustment
#' based on the grade and volume when using 
#' the percent-time-spent-following (PTSF) approach.
#' 
#' @format A data frame with 9 observations
#' \describe{
#'  \item{DemandFlowRate}{Demand flow rate in the analysis direction}
#'  \item{fg}{Grade adjustment (does not apply to level terrain)}
#' }
#' @source Exhibit 15-16 HCM 2010
"tlHighwayFgPTSF"

#' Two-Lane Highway - Grade adjustment (ATS)
#' 
#' A lookup table that provides the adjustment
#' based on the grade and volume when using 
#' the average-travel-speed (ATS) approach.
#' 
#' @format A data frame with 9 observations
#' \describe{
#'  \item{DemandFlowRate}{Demand flow rate in the analysis direction}
#'  \item{fg}{Grade adjustment (does not apply to level terrain)}
#' }
#' @source Exhibit 15-9 HCM 2010
"tlHighwayFgATS"

#' Two-Lane Highway - Truck PCEs (PTSF)
#' 
#' A lookup table that provides the passenger
#' car equivalent of trucks based on demand flow rate
#' in the analysis direction (veh/hr) and terrain
#' when using the percent-time-spent-following (PTSF) approach.
#' 
#' @format A data frame with 9 observations
#' \describe{
#'  \item{DemandFlowRate}{Demand flow rate in the analysis direction}
#'  \item{EtLevel}{PCE of trucks on level terrain}
#'  \item{EtRolling}{PCE of trucks on rolling terrain}
#' }
#' @source Exhibit 15-18 HCM 2010
"tlHighwayEtPTSF"

#' Two-Lane Highway - Truck PCEs (ATS)
#' 
#' A lookup table that provides the passenger
#' car equivalent of trucks based on demand flow rate
#' in the analysis direction (veh/hr) and terrain
#' when using the average-travel-speed (ATS) approach.
#' 
#' @format A data frame with 9 observations
#' \describe{
#'  \item{DemandFlowRate}{Volume (veh/hr)}
#'  \item{EtLevel}{PCE for level terrain}
#'  \item{EtRolling}{PCE for rolling terrain}
#' }
#' @source Exhibit 15-11 HCM 2010
"tlHighwayEtATS"

#' Two-Lane Highway - Percent no passing adjustment (PTSF)
#' 
#' A lookup table that provides the adjustment
#' based on the percent of no passing zone and
#' the volume when using the percent-time-spent-
#' following (PTSF) approach.
#' 
#' @format A data frame with 24 observations
#' \describe{
#'  \item{Volume}{Link volume.}
#'  \item{PctMajorFlow}{Percent major flow direction.}
#'  \item{PctNoPass}{Percent of no passing zone.}
#'  \item{fnp}{Adjustment factor.}
#' }
#' @source Exhibit 15-21 HCM 2010
"tlHighwayFnpPTSF"

#' Two-Lane Highway - Percent no passing adjustment (ATS)
#' 
#' A lookup table that provides the adjustment
#' based on the percent of no passing zones, 
#' opposing volume, and free-flow speed when
#' using the average-travel-speed (ATS) approach.
#' 
#' @format A data frame with 18 observations
#' \describe{
#'  \item{OpposingVol}{Volume in the opposite direction.}
#'  \item{FFS}{Free-flow speed.}
#'  \item{PctNoPass}{Percent no passing zone.}
#'  \item{fnp}{No-passing factor.}
#' }
#' @source Exhibit 15-15 HCM 2010
"tlHighwayFnpATS"

#' Sample Table of Highway Links
#' 
#' Created using the sampleTableCreation.r script.
#' Enumerates all combinations of highway attributes,
#' including some that should return warnings
#' and null values when evaluated.
#' 
#' @format A data frame with 4,536 observations
#' \describe{
#'  \item{ft}{Facility type}
#'  \item{at}{Area type}
#'  \item{sl}{Speed limit}
#'  \item{med}{Median type}
#'  \item{lanes}{Number of lanes (in one direction)}
#'  \item{terrain}{Terrain type}
#' }
#' @source sampleTableCreation.r
"hwylinks"

















