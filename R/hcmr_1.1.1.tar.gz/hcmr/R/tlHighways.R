#' HCM Two-Lane Highway Function
#'
#' This function takes link-level attributes and default values to calculate
#' hourly flow rates
#' for two-lane highway segments.
#' @inheritParams hcm_calculate
#' @export
#' @details This section documents some of the assumptions used
#' by the function.
#' Factors determined by the \code{terrain}.
#' \itemize{
#'  \item{Percent no-passing zone:\cr}{level: 20; rolling: 40; mountain: 60}
#' }
hcm_tlHighway <- function(speed = FALSE,
                          LOS = "E",
                          sl = 55,
                          terrain = "rolling"){
  
  # ---- Argument Checking ----
  if (sl < 45){
    warning("Raising speed limit to the minimum of 45.")
    sl <- 45
  }
  if (sl > 65){
    warning("Lowering speed limit to the maximum of 65.")
    sl <- 65
  }
  # ---- End Checking ----
  
  # Base free-flow speed (page 15-15)
  BFFS <- sl + 10
  # Adjustment for lane and shoulder width (Exhibit 15-7)
  fls <- 0
  # Access points per mile (NCLOS default)
  apd <- 10
  # Adjustment for access density (Exhibit 15-8)
  # (Same as multi-lane highway)
  fa <- mlHighwayAPD$Factor[match(round(apd),mlHighwayAPD$APD)]
  # Free-flow speed (Equation 15-2)
  FFS <- BFFS - fls - fa
  
  if (speed){
    return(round(FFS,0))
  }
  
  # Heavy Vehicles
  # Proportion heavy vehicles (NCLOS defaults)
  Pt <- .1
  # Proportion RVs (NCLOS default)
  Pr <- 0
  
  # Peak hour factor (NCLOS default)
  phf <- 0.95
  # Percent no passing zone (HCM defaults)
  pnpz <- ifelse(terrain == "level",20,
                 ifelse(terrain == "rolling",40,60))
  
  # Volume based on Average Travel Speed
  atsVol <- optimize(tlHighwayATS,
                     interval=c(100:10000),
                     FFS = FFS,
                     phf = phf,
                     pnpz = pnpz,
                     Pt = Pt,
                     Pr = Pr,
                     terrain = terrain,
                     LOS = LOS)
  atsVol <- round(atsVol$minimum,0)
  
  # Volume based on Percent Time Spent Following
  ptsfVol <- optimize(tlHighwayPTSF,
                     interval=c(100:10000),
                     phf = phf,
                     pnpz = pnpz,
                     Pt = Pt,
                     Pr = Pr,
                     terrain = terrain,
                     LOS = LOS)
  ptsfVol <- round(ptsfVol$minimum,0)
  
  # Return the smaller volume
  return(round(min(atsVol,ptsfVol),0))
}

#' HCM Two-Lane ATS Capacity
#'
#' This function is used to iteratively find the volume level that translates
#' into the specified level of service
#' 
#' @inheritParams hcm_tlHighway
#' @param vol Volume
#' @param FFS Free-flow speed
#' @param pnpz Percent no-passing zone
#' @param Pt Percent trucks
#' @param Pr Percent recreational vehicles
#' @param phf Peak hour factor
#' @param pfm Percent of flow in major direction
#' @inheritParams hcm_calculate
#' @import dplyr
#' @importFrom stats approx
#' 
#' @export
tlHighwayATS <- function(vol,FFS,phf,pnpz,Pt,Pr,terrain,LOS,pfm = 60){
  
  # Grade adjustment (Exhibit 15-9)
  fg <- 1
  if (terrain != "level"){
    fg <- round(as.numeric(
      stats::approx(tlHighwayFgATS$DemandFlowRate,
                    tlHighwayFgATS$fg,xout = vol,
                    rule = 2)[2]),4)
  }
  
  # Passenger car equivalent (PCE) of heavy vehicles 
  # (Exhibit 15-11)
  if (terrain != "level"){
    Et <- round(as.numeric(
      stats::approx(tlHighwayEtATS$DemandFlowRate,
                    tlHighwayEtATS$EtRolling,xout = vol,
                    rule = 2)[2]),4)
  }
  if (terrain == "level"){
    Et <- round(as.numeric(
      stats::approx(tlHighwayEtATS$DemandFlowRate,
                    tlHighwayEtATS$EtLevel,xout = vol,
                    rule = 2)[2]),4)
  }
  # Passenger car equivalents (PCE) of RVs
  # (Exhibit 15-11)
  # 1 if level; 1.1 if rolling
  Er <- ifelse(terrain == "level",1,1.1)
  # Adjustment for heavy vehicles (Equation 15-4)
  fhv <- 1/(1 + Pt * (Et - 1) + Pr * (Er - 1))
  
  
  # Adjust the volume from veh/h to pc/hr (Equation 15-3)
  vd <- vol / (phf * fhv * fg)
  
  # Opposing demand flow rate (based on pfm split)
  vo <- ((1 - pfm/100) * vd) / (pfm/100)
  
  # Lookup the no-passing adjustment based on
  # the nearest volume, FFS, and pct-no-passing value
  # (Exhibit 15-15)
  ffs1 <- tlHighwayFnpATS$FFS[
    which.min(abs(tlHighwayFnpATS$FFS - FFS))]
  pnpz1 <- tlHighwayFnpATS$PctNoPass[
    which.min(abs(tlHighwayFnpATS$PctNoPass - pnpz))]
  temp <- tlHighwayFnpATS %>%
    dplyr::filter(FFS == ffs1,
                  PctNoPass == pnpz1) %>%
    dplyr::select(OpposingVol,fnp)
  fnp <- round(as.numeric(
    stats::approx(temp$OpposingVol,
                  temp$fnp,xout = (vo),
                  rule = 2)[2]),1)
  
  # Average Travel Speed (Equation 15-6)
  ATS <- FFS - 0.00776 * (vd + vo) - fnp
  
  # Target value based on LOS
  target <- ifelse(LOS == "D",40,20)
  
  return(abs(ATS - target))
}


#' HCM Two-Lane PTSF Capacity
#'
#' This function is used to iteratively find the volume level that translates
#' into the specified level of service
#' 
#' @inheritParams hcm_tlHighway
#' @inheritParams tlHighwayATS
#' @param Pt percent trucks
#' @param Pr percent recreational vehicles
#' 
#' @export
#' @import dplyr
#' @importFrom stats approx
tlHighwayPTSF <- function(vol,LOS,phf,Pt,Pr,pnpz,terrain,pfm = 60){
  
  # Grade adjustment factor (Exhibit 15-16)
  fg <- 1
  if (terrain != "level"){
    fg <- round(as.numeric(
      stats::approx(tlHighwayFgPTSF$DemandFlowRate,
                    tlHighwayFgPTSF$fg,xout = vol,
                    rule = 2)[2]),4)
  }
  
  
  # Passenger car equivalent (PCE) of heavy vehicles 
  # (Exhibit 15-18)
  # 1.0 if level; 1.4 if rolling
  if (terrain != "level"){
    Et <- round(as.numeric(
      stats::approx(tlHighwayEtPTSF$DemandFlowRate,
                    tlHighwayEtPTSF$EtRolling,xout = vol,
                    rule = 2)[2]),4)
  }
  if (terrain == "level"){
    Et <- round(as.numeric(
      stats::approx(tlHighwayEtPTSF$DemandFlowRate,
                    tlHighwayEtPTSF$EtLevel,xout = vol,
                    rule = 2)[2]),4)
  }
  # Passenger car equivalent (PCE) of RVs 
  # (Exhibit 15-18)
  # 1.0 if level; 1.0 if rolling
  Er <- 1.0  
  # Adjustment for heavy vehicles (Equation 15-8)
  fhv <- 1/(1 + Pt * (Et - 1) + Pr * (Er - 1))  
  
  # Demand flow rate in primary direction (Equation 15-7)
  vd <- vol / (phf * fhv * fg)
  
  # Opposing demand flow rate (based on pfm split)
  vo <- ((1 - pfm/100) * vd) / (pfm/100)
  
  # Lookup the BPTSF coefficients.  Interpolate based on the volume.
  a <- round(as.numeric(
    stats::approx(bptsfCoeffTbl$DemandFlowRate,
                  bptsfCoeffTbl$a,xout = vo,
                  rule = 2)[2]),4)
  b <- round(as.numeric(
    stats::approx(bptsfCoeffTbl$DemandFlowRate,
                  bptsfCoeffTbl$b,xout = vo,
                  rule = 2)[2]),3)
  # Base Percent Time Spent Following (Equation 15-10)
  BPTSF <- 100 * (1 - exp(a * (vo)^b))
  
  # Adjustment for no passing zones (Exhibit 15-21)
  # Lookup the no-passing adjustment based on
  # the nearest value of PctMajorFlow and 
  # pct no passing value.  Interpolate volume to 0.1.
  pfm1 <- tlHighwayFnpPTSF$PctMajorFlow[
    which.min(abs(tlHighwayFnpPTSF$PctMajorFlow - pfm))]
  pnpz1 <- tlHighwayFnpPTSF$PctNoPass[
    which.min(abs(tlHighwayFnpPTSF$PctNoPass - pnpz))]
  temp <- tlHighwayFnpPTSF %>%
    dplyr::filter(PctMajorFlow == pfm1,
                  PctNoPass == pnpz1) %>%
    dplyr::select(Volume,fnp)
  fnp <- round(as.numeric(
    stats::approx(temp$Volume,
                  temp$fnp,xout = (vd + vo),
                  rule = 2)[2]),1)
  
  # Percent Time Spent Following (Equation 15-9)
  PTSF <- BPTSF + fnp * (vd / (vd + vo))
  
  # Target value based on LOS
  target <- ifelse(LOS == "D",80,90)
  
  return(abs(PTSF - 80))
}



