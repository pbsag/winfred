#' HCM Arterial Function
#'
#' This function takes link-level attributes
#' and default values to calculate hourly flow rates
#' for arterial segments.  For arterials, the returned
#' free-flow speed is actually the "running speed", which
#' includes signal delay.
#' @inheritParams hcm_calculate
#' @param type Whether the road is a principal or minor arterial.
#' @export
#' @importFrom stats optimize
#' @details This section documents some of the assumptions used
#' by the function.
#' Factors determined by the \code{at}.
#' \itemize{
#'  \item{Intersection spacing (mi):\cr}{Urban: 0.3; Suburban: 0.6; Rural: 1.5}
#'  \item{Proportion with curb:\cr}{Urban: 1; Suburban: 0.7; Rural: 0}
#'  \item{Access point density (per mile)\cr}{Urban: 25; Suburban: 16; Rural: 8}
#' }
#' Assumed platoon ratios
#' \itemize{
#'  \item{Urban Principal: }{0.60}
#'  \item{Urban Minor: }{0.50}
#'  \item{Other Principal: }{0.60}
#'  \item{Other Minor: }{0.50}
#' }
#' Assumed proportion of green time
#' \itemize{
#'  \item{Urban Principal: }{0.70}
#'  \item{Urban Minor: }{0.60}
#'  \item{Other Principal: }{0.70}
#'  \item{Other Minor: }{0.60}
#' }
#' Assumed cycle length (sec)
#' \itemize{
#'  \item{Urban Principal: }{120}
#'  \item{Urban Minor: }{90}
#'  \item{Other Principal: }{150}
#'  \item{Other Minor: }{120}
#' }
#' Factors determined by the \code{med}.
#' \itemize{
#'  \item{Proportion with median:\cr}{Restrictive: 0.8; NonRestrictive: 0.37; None: 0}
#' }
#' @examples
#' \dontrun{
#' hcm_arterial(LOS = "E")
#' }
hcm_arterial <- function(speed=FALSE,
                         LOS = "E",
                         type = "m",
                         at=2,
                         lanes = 1,
                         sl = 45,
                         med = "None",
                         terrain = "rolling"){
  
  # ---- Argument Checking ----
  if (!(type %in% c("p","m"))){
    warning(paste0("type must be either 'p' (principal) or",
                   " 'm' (minor). Setting to 'p'."))
    type <- "p"
  }
  # ---- End Checking ----
  
  # Exhibit 30-8
  
  # Length (ft)
  # Average length between intersections/signals
  # (not model link length!)
  L <- ifelse(at == 1,.30 * 5280,
              ifelse(at == 2,.6 * 5280,1.5 * 5280))
  # Startup lost time (sec) (using HCM default)
  # (NCLOS uses 1.5)
  l1 <- 1.5
  # Proportion of link with curb
  pcurb = ifelse(at == 1,1,
                 ifelse(at == 2,.75,0))
  # Proportion with restrictive median
  #(NCLOS uses .37)
  prm <- ifelse(med == "Restrictive",.8,
                ifelse(med == "NonRestrictive",.37,0))
  # Speed constant (mph)
  s0 <- 25.6 + 0.47 * sl
  # Cross section adjustment (mph)
  fcs <- 1.5 * prm - 0.47 * pcurb - 3.7 * pcurb * prm
  # Access Point Density (points per mile)
  da <- ifelse(at == 1,25,
               ifelse(at == 2,16,8))
  # Adjustment for access points
  fa <- -0.078 * da / lanes
  # Base Free-Flow Speed (mph)
  Sfo <- s0 + fcs + fa
  # Segment length adjustment factor
  fl <- 1.02 - 4.7 * (Sfo - 19.5) / max(L,400)
  fl <- min(fl,1)
  # Free-flow speed (mph)
  Sf <- Sfo * fl

  
  # Delay per turn (sec) (Exhibit 17-13)
  delayPerTurn <- .16
  # Total delay due to turns into access points (sec)
  dap <- delayPerTurn * da * (L / 5280)
  dap <- .5
  dap <- .25
  # Other delays (sec)
  # (NCLOS uses 10)
  dother <- 0
  # Running Time (sec)
  tr <- (6 - l1) / (0.0025 * L) + (3600 * L) / (5280 * Sf)
  tr <- tr + dap + dother
  
  
  # Exhibit 30-9
  
  # Platoon Ratio
  # (NCLOS default = 0.6)
  Rp <- ifelse(at == 1,
               ifelse(type == "p",0.60,0.50), # urban
               ifelse(type == "p",0.50,0.40)) # non urban
  # Effective green-to-cycle length ratio
  #(NCLOS defaults .42 for urban; .55 else)
  gC <- ifelse(at == 1,
               ifelse(type == "p",0.70,0.60), # urban
               ifelse(type == "p",0.60,0.50)) # non urban
  # Proportion arriving during green
  P <- Rp * gC

  
  # Exhibit 30-10
  
  # Saturation flow rate
  s <- 1800
  # Cycle Length (sec) (NCLOS defaults)
  C <- ifelse(at == 1,
    ifelse(type == "p",120,90),   # urban
    ifelse(type == "p",150,120))  # suburban
  # Capacity
  c <- lanes * s * gC

  # If the user wants FFS, return it
  if (speed){
    # convert running time to running speed
    #Sr = (L / 5280) / (tr / 3600)
    #return(round(Sr,0))
    
    # Run the function with 0 volume, and
    # an argument to return just the
    # control delay.
    control.delay <- arterialPBFFS(
      0,
      L = L,
      c = c,
      Sfo = Sfo,
      Sf = Sf,
      LOS = LOS,
      at = at,
      lanes = lanes,
      med = med,
      terrain = terrain,
      C = C,
      gC = gC,
      P = P,
      tr = tr,
      delay = TRUE
    )
    
    # Add it to the running time
    total.time <- tr + control.delay
    
    # Convert to MPH
    final.speed <- (L / 5280) / (total.time / 3600)
    
    return(final.speed)
  }    
  
  # If the user wants volume, optimize the
  # arterialPBFFS function such that the volume
  # leads to the appropriate speed for the given
  # LOS. (Can't solve for volume given LOS.)
  
  # Volume based on PBFFS
  pbffsVol <- stats::optimize(arterialPBFFS,
                       interval=c(100:c),
                       L = L,
                       c = c,
                       Sfo = Sfo,
                       Sf = Sf,
                       LOS = LOS,
                       at = at,
                       lanes = lanes,
                       med = med,
                       terrain = terrain,
                       C = C,
                       gC = gC,
                       P = P,
                       tr = tr)
  pbffsVol$minimum
}





#' Arterial Percent of Base Free-flow Speed
#'
#' This function takes volume, capacity,
#' and other parameters and returns the LOS
#' based on PBFFS.
#' @inheritParams hcm_calculate
#' @param vol Volume (veh/hr)
#' @param Sfo Base free-flow speed (mph)
#' @param Sf Free-flow speed (mph)
#' @param L Segment length (ft)
#' @param c Ultimate capacity
#' @param C Cycle Length (sec)
#' @param gC Effective green time to cycle length ratio
#' @param P Proportion arriving during green
#' @param tr Running time
#' @param delay T/F whether to return the control delay

arterialPBFFS <- function(vol,L,c,Sfo,Sf,LOS,
                          at,lanes,med,
                          terrain,C,gC,P,tr,
                          delay = FALSE){
  # Convert midsegment volume to through volume
  # Remainder is left and right turns
  vth <- vol * .9
  # Volume-to-Capacity Ratio
  X <- vth / c
  
  
  # Exhibit 30-10
  
  # Analysis period (hours)
  T <- 0.25
  # Uniform Delay
  d1 <- (0.5 * C * (1 - gC)^2) / (1 - (min(1,X * gC)))
  # Upstream v/c ratio (HCM default)
  # (NCLOS uses .9)
  Xu <- .57
  # Upstream filtering adjustment factor (NCLOS default)
  I <- 1 - .91 * Xu ^ 2.68
  # Incremental Delay
  d2 <- 900 * T * ((X - 1) + ((X - 1)^2 + (4 * I * X)/(c * T))^.5)
  # Progression adjustment factor
  PF <- (1 - P) / (1 - gC)
  # Control Delay (sec/veh)
  d <- d1 * PF + d2
  
  # If control delay is desired, return it
  if (delay){
    return(d)
  }
  
  # Exhibit 30-12
  
  # Travel Time
  Tt <- tr + d
  # Travel Speed (mph)
  St <- (3600 * L) / (5280 * Tt)
  # Percent of base ff speed
  # R <- 100 * St / Sfo
  R <- 100 * St / Sf
  
  # Target LOS value
  Rt <- ifelse(LOS == "E",30,40)
  
  test <- abs(R - Rt)
  return(test)
}












