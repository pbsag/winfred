#' HCM Multi-Lane Highway Function
#'
#' This function takes link-level attributes
#' and default values to calculate hourly flow rates
#' for multi-lane highway segments.
#' @inheritParams hcm_calculate
#' @export
#' 
#' @details This section documents some of the assumptions used
#' by the function.
#' Min/Max speed limit is 45/60 mph, and the minimum
#' number of lanes is 2.
#' 
#' Factors determined by the \code{at}.
#' \itemize{
#'  \item{Lane width:\cr}{Urban: 12'; Suburban: 12'; Rural: 11'}
#'  \item{Lateral clearance:\cr}{Urban: 12'; Suburban: 10'; Rural: 8'}
#'  \item{Access point density:\cr}{Urban: 30; Suburban: 20; Rural: 5}
#'  \item{Proportion of Heavy Vehicles:\cr}{Urban: 0.05; Suburban: 0.08; Rural: 0.1}
#' }
#' 
#' Factors determined by the \code{terrain}.
#' \itemize{
#'  \item{Passenger-Car Equivalent of Heavy Vehicles:\cr}{level: 1.5; rolling: 2.5; mountain: 4.5}
#'  \item{Passenger-Car Equivalent of Recreational Vehicles:\cr}{level: 1.2; rolling: 2.0; mountain: 4.0}
#' }
#' 
#' @examples
#' hcm_mlHighway(LOS = "E")

hcm_mlHighway <- function(speed = FALSE,
                          LOS = "E",
                          at = 3,
                          lanes = 2,
                          sl = 55,
                          med = "Restrictive",
                          terrain = "rolling"){
  # ---- Argument Checking ----
  if (sl < 45){
    warning(paste0("Minimum speed limit for ML Highways is 45. ",
                 "Setting speed to 45."))
    sl <- 45
  }
  if (sl > 60){
    warning(paste0("Maximum speed limit for ML Highways is 60. ",
                 "Setting speed to 60."))
    sl <- 60
  }
  if (lanes < 2){
    warning("Raising directional lanes to the minimum of 2.")
    lanes <- 2
  }
  # ---- End Checking ----
  
  # Base free flow speed (HCM page 14-11)
  # NCLOS assumes 60
  BFFS <- ifelse(sl >= 50, sl + 5, sl + 7)
  # Lane width
  lw <- ifelse(at == 3,12,
               ifelse(at == 2,12,11))
  # Adjustment for lane width (Exhibit 14-8)
  flw <- ifelse(lw >= 12,0,
                ifelse(lw >= 11,1.9,6.6))
  # Lateral clearance (NCLOS assumptions)
  lc <- ifelse(at == 3,12,
               ifelse(at == 2,10,8))
  # Adjustment for total lateral clearance (Exhibit 14-9)
  flc <- ifelse(lc == 12, 0,
                ifelse(lc == 10, .4, .9))
  # Adjustment for median type
  fm <- ifelse(med == "None",1.6,0)
  # Access point density
  # (NCLOS defaults: 30,20,10)
  apd <- ifelse(at == 1, 30,
                ifelse(at == 2, 20, 5))
  # Adjustment for access point density (Exhibit 14-11)
  fa <- mlHighwayAPD$Factor[which.min(abs(mlHighwayAPD$APD - apd))]
  # Free flow speed (Equation 14-1)
  FFS <- BFFS - flw - flc - fm - fa
  if (speed){
    return(round(FFS,0))
  }
  
  
  # Select nearest FFS speed curve (Exhibit 14-2)
  FFS <- max(min(round(FFS / 5,0) * 5,60),45)
  
  # Maximum Service Flow Rate (Exhibit 14-17)
  MSF <- mlHighwayMSF[match(FFS,mlHighwayMSF$FFS),paste0("LOS",LOS)]  
  
  # Heavy Vehicles
  # Proportion heavy vehicles
  # (NCLOS defaults: .1,.08,.5)
  Pt <- ifelse(at == 3,.1,
               ifelse(at == 2,.08,.05))
  # Passenger car equivalent (PCE) of heavy vehicles 
  # (Exhibit 14-12)
  # 1.5 if level; 2.5 if rolling; 4.5 if mountainous
  Et <- ifelse(terrain == "level",1.5,
               ifelse(terrain == "rolling",2.5,4.5))
  # Proportion RVs (NCLOS default)
  Pr <- 0
  # Passenger car equivalents (PCE) of RVs
  # (Exhibit 14-12)
  # 1.2 if level; 2.0 if rolling; 4.0 if mountainous
  Er <- ifelse(terrain == "level",1.2,
               ifelse(terrain == "rolling",2.0,4.0))
  # Adjustment for heavy vehicles (Equation 14-4)
  fhv <- 1/(1 + Pt * (Et - 1) + Pr * (Er - 1))
  
  # Adjustment for driver population (NCLOS default)
  fp <- 1
  # Service flow rate
  SF <- MSF * lanes * fhv * fp
  # Peak Hour Factor
  phf <- 0.9
  # Service volume
  SV <- SF * phf
  
  return(round(SV[1,1],0))
}










