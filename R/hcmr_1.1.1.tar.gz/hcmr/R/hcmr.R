#' hcmr: A package to compute link capacities and freeflow speeds
#' 
#' The primary function for users is \code{\link{hcm_calculate}}
#' 
#' @docType package
#' @name hcmr
NULL
#> NULL


#' Highway Capacity Calculation Function
#'
#' Calculates the Highway Capacity Manual (2010) free flow speed or capacity based
#' on link attributes. 
#' 
#' @param ft Facility type field. Must be one of \code{c("Freeway", "MLHighway",
#'   "TLHighway", "PrArterial", "MinArterial", "Collector","Local")}. See
#'   \code{Details}. Default is \code{Freeway}.
#' @param at Area type field; one of \code{c("Urban", "Suburban", "Rural")}.
#'   Default is \code{Suburban}
#' @param sl Posted speed limit in miles per hour.
#' @param med Median treatment; one of \code{c("Restrictive",
#'   "Non-Restrictive", "None")}. \code{Restrictive} median treatments do not
#'   allow left turns except at designated locations, \code{Non-Restrictive}
#'   treatments have a center two-way-left-turn lane, and \code{None} implies
#'   that there is no median treatment at all (a double yellow line). Default is
#'   \code{Restrictive}.
#' @param lanes Number of through lanes for single direction. 
#' @param terrain Terrain type, either "level","rolling" (default), or "mountain".
#' @param LOS Specifies the Level of Service to return(NA) ("D" or "E"). Typically 
#'   volume-to-delay functions in assignment algorithms use LOS E, though
#'   certain planning applications prefer to look at LOS D.
#' @param speed Estimated free flow speed (\code{TRUE}), or estimated
#'   capacity (\code{FALSE}, default).
#'   
#' @return If \code{speed == FALSE}(default), the HCM 2010 link capacity in 
#'   vehicles per hour. Otherwise, the HCM 2010 link free flow speed in miles
#'   per hour.
#' 
#' @details This function is a vectorized wrapper to \code{\link{hcm_ftCheck}}, 
#'   which determines which HCM methodology to apply based on the labeled 
#'   \code{ft} field. Though this function uses several default values if they 
#'   are not supplied, these defaults may be overridden in the individual facility
#'   type calculators.
#'   
#' @export
hcm_calculate <- function(ft = "Freeway",
                     at = "Suburban",
                     sl = 65,
                     med = "Restrictive",
                     lanes = 2,
                     terrain = "rolling",
                     LOS = "E",
                     speed = FALSE){
  
  l <- mapply(hcm_ftCheck, ft = ft, at = at, sl = sl, med = med,
         lanes = lanes, terrain = terrain, LOS = LOS, speed = speed
         )
  round(unlist(l), 0)
  
}


#' HCM Facility Type Check
#'
#' This function uses the facility type to select the appropriate function to
#' perform the speed and capacity calculations.
#' 
#' @inheritParams hcm_calculate
#' 
hcm_ftCheck <- function(ft = ft,
                          at = at,
                          sl = sl,
                          med = med,
                          lanes = lanes,
                          terrain = terrain,
                          LOS = LOS,
                          speed = speed){
  # ---- Argument Checking ----
  if (!(ft %in% c("Freeway",
                  "MLHighway",
                  "TLHighway",
                  "PrArterial",
                  "MinArterial",
                  "Collector",
                  "Local"))) {
    warning("Invalid facility type. return(NA)ing null.")
    return(NA)
  }
  if (!(at %in% c("Urban", "Suburban", "Rural"))) {
    warning("at must be Urban, Suburban, or Rural. return(NA)ing null.")
    return(NA)
  }
  if (sl <= 0) {
    warning("sl must be > 0. returning null.")
    return(NA)
  }
  if (!(med %in% c("Restrictive","NonRestrictive","None"))){
    print("med must be 'Restrictive', 'NonRestrictive', or 'None'. returning null.")
    return(NA)
  }
  if (lanes <= 0){
    warning("lanes must be > 0. returning null.")
    return(NA)
  }
  if (!(terrain %in% c("rolling","level","mountain"))){
    warning("terrain must be either 'rolling', 'level', or 'mountain'. returning null.")
    return(NA)
  }
  if (!(LOS %in% c("D","E"))){
    warning("LOS must be either 'D' or 'E'. returning null.")
    return(NA)
  }
  if (!(speed %in% c(TRUE,FALSE))){
    warning("speed must be either TRUE or FALSE. returning null.")
    return(NA)
  }
  #   if (){
  #     warning()
  #     return(NA)()
  #   }
  # ---- End Checking ----
  
  # convert area type to numeric vector
  if(at == "Urban"){
    at <- 1
  } else if(at == "Suburban"){
    at <- 2
  } else if(at == "Rural"){
    at <- 3
  }
  
  # Call the proper function depending on the facility type
  val <- ifelse(
    ft == "Freeway",
    hcm_freeway(
      speed = speed,
      LOS = LOS,
      at = at,
      lanes = lanes,
      terrain = terrain),
    
    ifelse(
      ft == "MLHighway",
      hcm_mlHighway(
        speed = speed,
        LOS = LOS,
        at = at,
        lanes = lanes,
        sl = sl,
        med = med,
        terrain = terrain),
      
      ifelse(
        ft == "TLHighway",
        hcm_tlHighway(
          speed = speed,
          LOS = LOS,
          sl = sl,
          terrain = terrain),
        
        ifelse(
          ft == "PrArterial",
          hcm_arterial(
            speed = speed,
            LOS = LOS,
            type = "p",
            at = at,
            lanes = lanes,
            sl = sl,
            med = med,
            terrain = terrain),
          
          ifelse(
            ft == "MinArterial",
            hcm_arterial(
              speed = speed,
              LOS = LOS,
              type = "m",
              at = at,
              lanes = lanes,
              sl = sl,
              med = med,
              terrain = terrain),
            
            ifelse(
              ft == "Collector",
              hcm_collector(
                speed = speed,
                LOS = LOS,
                at = at,
                lanes = lanes,
                sl = sl),
              
              ifelse(
                ft == "Local",
                hcm_local(
                  speed = speed,
                  LOS = LOS,
                  at = at,
                  lanes = lanes,
                  sl = sl)
              )
            )
          )
        )
      )
    )
  )
  
  val
}










