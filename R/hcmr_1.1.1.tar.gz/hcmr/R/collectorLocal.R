#' Collector Function (not HCM based)
#'
#' This function takes basic link-level attributes
#' and returns speed or hourly flow rate (veh/hr).
#' @inheritParams hcm_calculate
#' @export
#' @details This section documents some of the assumptions used
#' by the function.
#' Factors determined by the \code{at}.
#' \itemize{
#'  \item{Posted to free-flow speed adjustment:\cr}{
#'    Urban: \code{sl} - 0.50 * \code{sl} + 8.5\cr
#'    Suburban: \code{sl} - .25 * \code{sl} + 3.25\cr
#'    Rural: \code{sl}
#'  }
#'  \item{LOS D capacities per lane\cr}{
#'    Urban: 650\cr
#'    Suburban: 750\cr
#'    Rural: 750
#'  }
#' }
#' LOS E capacities are the LOS D + 100
#' @examples
#' hcm_collector(LOS = "E")

hcm_collector <- function(speed = FALSE,
                      LOS = "E",
                      at = 2,
                      lanes = 1,
                      sl = 35){
  FFS <- ifelse(at == 1, sl - .50 * sl + 8.5,
                ifelse(at == 2,sl - .25 * sl + 3.25,sl))
  if (speed){
    return(FFS)
  }
  
  # LOS D flow rates
  capPerLane <- ifelse(at == 1,650,
                       ifelse(at == 2,750,750))
  # Add to flow rate if LOS E
  if (LOS == "E"){
    capPerLane <- capPerLane + 100
  }
  
  capPerLane * lanes
}




#' Local Function (not HCM based)
#'
#' This function takes basic link-level attributes
#' and returns speed or hourly flow rate (veh/hr).
#' @inheritParams hcm_calculate
#' @export
#' @details Factors determined by the \code{at}.
#' \itemize{
#'  \item{Posted to free-flow speed adjustment:\cr}{
#'    Urban: \code{sl} - 0.50 * \code{sl} + 7.5\cr
#'    Suburban: \code{sl} - .25 * \code{sl} + 2.25\cr
#'    Rural: \code{sl} - 1
#'  }
#'  \item{LOS D capacities per lane\cr}{
#'    Urban: 600\cr
#'    Suburban: 700\cr
#'    Rural: 700
#'  }
#' }
#' LOS E capacities are the LOS D + 100
#' @examples
#' hcm_local(LOS = "E")
hcm_local <- function(speed = FALSE,
                  LOS = "E",
                  at = 2,
                  lanes = 1,
                  sl = 25){
  
  FFS <- ifelse(at == 1, sl - .50 * sl + 7.5,
                ifelse(at == 2,sl - .25 * sl + 2.25,sl - 1))
  if (speed){
    return(FFS)
  }
  
  # LOS D flow rates
  capPerLane <- ifelse(at == 1,600,
                       ifelse(at == 2,700,700))
  # Add to flow rate if LOS E
  if (LOS == "E"){
    capPerLane <- capPerLane + 100
  }
  capPerLane * lanes
}