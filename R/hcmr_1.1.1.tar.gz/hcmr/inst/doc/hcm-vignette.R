## ---- results='hide',warning=FALSE,message=FALSE-------------------------
library(dplyr)
library(knitr)
library(readr)
library(hcmr)
library(ggplot2)

## ----echo=FALSE----------------------------------------------------------
hwylinks %>%
  head() %>%
  kable()

## ------------------------------------------------------------------------
hcm_calculate(ft = "Freeway",lanes = 1)

## ----warning=FALSE,message=FALSE-----------------------------------------
subTbl <- hwylinks %>%
  filter(lanes == 1,terrain == "rolling")

subTbl <- subTbl %>%
  mutate(
    capD = hcm_calculate(
      ft = ft,at = at,sl = sl,
      med = med,lanes = lanes,terrain = terrain,
      LOS = "D",speed=FALSE),
    FFS = hcm_calculate(
      ft = ft,at = at,sl = sl,
      med = med,lanes = lanes,terrain = terrain,
      LOS = "D",speed=TRUE)
  )


## ------------------------------------------------------------------------
subTbl <- subTbl %>%
  mutate(
    capD = ifelse(
      ft %in% c("Freeway","MLHighway"),capD / 2,capD)
  )

## ----fig.cap="LOS D Capacities by Posted Speed",fig.width=8,fig.height=6----
ggplot(subTbl,aes(x = sl,y = capD)) +
  geom_line(aes(color = ft,lty = med)) + 
  facet_wrap(~ at)

## ---- echo=FALSE,warning=FALSE,message=FALSE-----------------------------
subTbl <- hwylinks %>%
  filter(lanes == 1,terrain == "rolling")

subTbl <- subTbl %>%
  mutate(
    capE = hcm_calculate(
      ft = ft,at = at,sl = sl,
      med = med,lanes = lanes,terrain = terrain,
      LOS = "E",speed=FALSE),
    FFS = hcm_calculate(
      ft = ft,at = at,sl = sl,
      med = med,lanes = lanes,terrain = terrain,
      LOS = "E",speed=TRUE)
  )

subTbl <- subTbl %>%
  mutate(
    capE = ifelse(
      ft %in% c("Freeway","MLHighway"),capE / 2,capE)
  )

## ----fig.cap="LOS E Capacities by Posted Speed",fig.width=8,fig.height=6----
ggplot(subTbl,aes(x = sl,y = capE)) +
  geom_line(aes(color = ft,lty = med)) + 
  facet_wrap(~ at)

## ----warning=FALSE,message=FALSE-----------------------------------------
subTbl <- subTbl %>%
  mutate(
    FFS = hcm_calculate(
      ft = ft,at = at,sl = sl,
      med = med,lanes = lanes,terrain = terrain,
      speed=TRUE)
  )

## ----fig.cap="Free-Flow Speed by Posted Speed",fig.width=8,fig.height=6----
ggplot(subTbl,aes(x = sl,y = FFS)) +
  geom_line(aes(color = ft,lty = med)) + 
  facet_wrap(~ at)

