hcmr
=====================

This package contains functionality to calculate link capacities and free flow
speeds given a set of link attributes.

```r
hcm_calculate(
  ft = "Freeway", at = "Urban", sl = 65, lanes = 3, 
  terrain = "rolling", LOS = "E"
)

## Freeway 
##    5535 
```

This function is fully vectorized so that it works on a table of values as well 
as a single link. This makes it ideal for implementation inside a travel demand
model where many thousands of links must receive capacities based on attributes
that change with the scenario.

For details on using the package, see `?hcm_calculate()` and
`vignette("hcm-vignette")`.

The package applies a number of simplifying assumptions to adapt specific HCM
methodologies to a planning-level capacity calculation. For instance, many 
factors related to driveway/ramp spacing are replaced with default values varying
by area type. These assumptions are detailed in the manual file for the respective
functions.

### Acknowledgements
The  North Carolina Department of Transportation funded this package.